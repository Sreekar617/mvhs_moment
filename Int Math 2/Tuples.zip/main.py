fiction = ('Rosalina, Luigi, Luma')
print(fiction)