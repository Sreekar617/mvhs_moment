a = 5
while a > 0:
  print('THIS WILL REPEAT 5 TIMES')
  a = a - 1