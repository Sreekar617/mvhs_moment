a = input('Name a verb ending in ‘ing’. ')
b = input('Name a noun. ')
c = input('Name something a cat would want to do. ')
print('My dog is', a, 'too much because we gave him too much', b, '. It just makes my cat want to', c, '.' )