states = input('How many states have you been to? ')
tv = input('How many TVs do you have in your house? ')
print('You have been to', states, 'states and have', tv, 'TVs.')