a = input('Name a verb ending in ‘ing’. ')
b = input('Name a noun. ')
c = input('Name a crazy word. ')
print('Chippewa is', a, 'too much because they bought a new', b, '. It just makes me want to say', c,'!!!!!!!!' )