mass = 50
volume = 25
density = mass/volume
print(density)