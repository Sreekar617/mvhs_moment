games = input('Do you play video games?\n')
if games == 'yes':
  minecraft = input('Do you play Minecraft?\n')
  if minecraft == 'yes':
    print('Minecraft is a great game.')
  else:
    print('You should play Minecraft')

else:
  print('You should play video games.')