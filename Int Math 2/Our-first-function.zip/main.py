def helloworld():
  print('Hello World!')
helloworld()