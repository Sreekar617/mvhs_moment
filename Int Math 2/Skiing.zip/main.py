ski = input('Do you know how to ski?\n')
if ski == 'yes':
  print('join ski club')

else:
  print('learn to ski and join ski club')