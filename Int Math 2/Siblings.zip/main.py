siblings = input('How many siblings do you have? ')
print('Wow!  I can’t believe that you have', siblings, 'siblings.')