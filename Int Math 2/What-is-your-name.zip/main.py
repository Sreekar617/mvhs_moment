name = input('What is your name? ')
if name == 'Hieb':
  print('Greetings, Lord', name, ', How may I automate repetitive tasks for you today?')

else:
  print('Hi', name)
#Totally not biased