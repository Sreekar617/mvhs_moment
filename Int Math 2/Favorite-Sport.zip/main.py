sport = input('What is your favorite sport?\n')
if sport == 'Soccer':
  print('That\'s great! I wonder if Brazil will make it far this season.')
elif sport == 'Football':
  print('That\'s wonderful! I wonder who will win the Super Bowl this season')
elif sport == 'Hockey':
  print('Don\'t hurt yourself on the ice!')
else:
  print('That\'s wonderful! I love', sport, 'too!')