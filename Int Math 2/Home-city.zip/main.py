city = input('What is your home city? ')
if city == 'Shoreview':
  print('That\'s nice. Shoreview is a good city.')

else:
  print('I hope your city is as nice as shoreview!')