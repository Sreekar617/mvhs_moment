sweat = input('Do you click above 9 cps?\n')
if sweat == 'yes':
  print('sweat')

else:
  print('noob')