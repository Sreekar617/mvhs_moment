shows = ['Bluey', 'Peppa Pig', 'Puppy Dog Pals']
shows.append('Teen Titans Go')
shows.append('We Bare Bears')
shows.remove('Puppy Dog Pals')
print(shows)